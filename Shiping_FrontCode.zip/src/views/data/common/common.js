export const tabs = [
  {
    label: "组织架构",
    name: "organization"
  },
  {
    label: "用户账号",
    name: "account"
  },
  {
    label: "网络区间",
    name: "network"
  }
];
