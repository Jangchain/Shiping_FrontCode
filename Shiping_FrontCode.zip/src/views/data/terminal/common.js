export const tabs = [
  {
    label: "终端信息源组",
    name: "terminalGroup"
  }
];
