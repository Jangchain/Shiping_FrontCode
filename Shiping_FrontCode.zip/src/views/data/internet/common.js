export const tabs = [
  {
    label: "端口资源",
    name: "portResource"
  },
  // {
  //   label: "邮件资源",
  //   name: "emailResource"
  // },
  // {
  //   label: "URL资源",
  //   name: "urlResource"
  // }
];
