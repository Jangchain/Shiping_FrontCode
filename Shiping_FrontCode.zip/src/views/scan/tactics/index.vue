<template>
  <div class="dashboard-container">
    <router-view></router-view>
  </div>
</template>

<script>

</script>

