export const tabs = [
  {
    label: "数据资产分布",
    name: "asset"
  },
  {
    label: "数据出境检查",
    name: "exit"
  },
  {
    label: "数据采集安全",
    name: "ftp"
  },
  {
    label: "数据传输安全",
    name: "linux"
  },
  {
    label: "数据使用/处理安全",
    name: "exchange"
  },
  {
    label: "数据分析安全",
    name: "lotus"
  },
  {
    label: "数据导入导出安全",
    name: "webDav"
  },
  {
    label: "数据共享/交换安全",
    name: "cloudDatabase"
  },
  {
    label: "数据发布安全",
    name: "cloudStorage"
  },
  {
    label: "数据销毁安全",
    name: "cloudStorage1"
  },
];
